# ============================================================
#          LRU Cache - Manual Test Cases
# ============================================================

from lru_cache import LRUCache

def run_tests():
    print("=" * 50)
    print("       LRU Cache - Manual Testing")
    print("=" * 50)

    # ----------------------------
    # Test 1: Basic GET and PUT
    # ----------------------------
    print("\n[Test 1] Basic GET and PUT")
    cache = LRUCache(2)
    cache.put(1, 10)
    cache.put(2, 20)
    result = cache.get(1)
    print(f"  get(1) => {result} | Expected: 10 | {'PASS ✅' if result == 10 else 'FAIL ❌'}")

    # ----------------------------
    # Test 2: Eviction of LRU item
    # ----------------------------
    print("\n[Test 2] Eviction of LRU item")
    cache = LRUCache(2)
    cache.put(1, 10)
    cache.put(2, 20)
    cache.get(1)       # 1 is recently used
    cache.put(3, 30)   # 2 should be evicted
    result = cache.get(2)
    print(f"  get(2) => {result} | Expected: -1 | {'PASS ✅' if result == -1 else 'FAIL ❌'}")
    result = cache.get(3)
    print(f"  get(3) => {result} | Expected: 30 | {'PASS ✅' if result == 30 else 'FAIL ❌'}")

    # ----------------------------
    # Test 3: Key not found
    # ----------------------------
    print("\n[Test 3] Key not found")
    cache = LRUCache(2)
    result = cache.get(99)
    print(f"  get(99) => {result} | Expected: -1 | {'PASS ✅' if result == -1 else 'FAIL ❌'}")

    # ----------------------------
    # Test 4: Update existing key
    # ----------------------------
    print("\n[Test 4] Update existing key")
    cache = LRUCache(2)
    cache.put(1, 10)
    cache.put(1, 100)  # update value
    result = cache.get(1)
    print(f"  get(1) => {result} | Expected: 100 | {'PASS ✅' if result == 100 else 'FAIL ❌'}")

    # ----------------------------
    # Test 5: Capacity = 1
    # ----------------------------
    print("\n[Test 5] Capacity = 1")
    cache = LRUCache(1)
    cache.put(1, 10)
    cache.put(2, 20)   # 1 should be evicted
    result1 = cache.get(1)
    result2 = cache.get(2)
    print(f"  get(1) => {result1} | Expected: -1 | {'PASS ✅' if result1 == -1 else 'FAIL ❌'}")
    print(f"  get(2) => {result2} | Expected: 20 | {'PASS ✅' if result2 == 20 else 'FAIL ❌'}")

    # ----------------------------
    # Test 6: Display cache state
    # ----------------------------
    print("\n[Test 6] Display Cache State")
    cache = LRUCache(3)
    cache.put(1, 10)
    cache.put(2, 20)
    cache.put(3, 30)
    cache.get(1)
    cache.display()

    print("\n" + "=" * 50)
    print("       All Tests Completed!")
    print("=" * 50)

if __name__ == "__main__":
    run_tests()
