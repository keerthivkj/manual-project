# LRU Cache - Python Implementation

## What is LRU Cache?
LRU (Least Recently Used) Cache evicts the least recently used item when the cache is full.

## Files
| File | Description |
|------|-------------|
| `lru_cache.py` | LRU Cache implementation using OrderedDict |
| `test_lru_cache.py` | Manual test cases |

## How to Run

```bash
python test_lru_cache.py
```

## Test Cases Covered
| Test | Description |
|------|-------------|
| Test 1 | Basic GET and PUT |
| Test 2 | Eviction of LRU item |
| Test 3 | Key not found returns -1 |
| Test 4 | Update existing key |
| Test 5 | Capacity = 1 edge case |
| Test 6 | Display cache state |

## Example Usage

```python
from lru_cache import LRUCache

cache = LRUCache(2)
cache.put(1, 10)
cache.put(2, 20)
print(cache.get(1))   # Output: 10
cache.put(3, 30)      # Evicts key 2
print(cache.get(2))   # Output: -1
```
